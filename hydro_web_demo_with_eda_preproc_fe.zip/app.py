
from flask import Flask, request, jsonify, render_template, send_from_directory
import os, json
from utils.inference import HydroDemoRuntime
from utils.eda import run_eda_hydro, run_eda_weather
from utils.pipeline import preprocess_merge, feature_engineer_for_trees

app = Flask(__name__)

BASE_DIR   = os.path.dirname(__file__)
MODELS_DIR = os.path.join(BASE_DIR, "models")
DATA_DIR   = os.path.join(BASE_DIR, "data")
REPORTS_DIR= os.path.join(BASE_DIR, "reports")
PLOTS_DIR  = os.path.join(REPORTS_DIR, "plots")

paths = {
    "enriched_csv": os.path.join(DATA_DIR, "data_thuydien_enriched.csv"),
    "xgb_model":    os.path.join(MODELS_DIR, "xgb_model.json"),
    "xgb_feats":    os.path.join(MODELS_DIR, "features_used_xgb.json"),
    "dtree_model":  os.path.join(MODELS_DIR, "dtree_model.pkl"),
    "dtree_feats":  os.path.join(MODELS_DIR, "features_used_dtree.json"),
    "cnn_model":    os.path.join(MODELS_DIR, "cnn_lstm_model_seq6_28d.pth"),
    "seq_scaler":   os.path.join(MODELS_DIR, "seq_scaler_28d_stride1_6ch.pkl"),
    "y_scaler":     os.path.join(MODELS_DIR, "y_scaler_28d_stride1_6ch.pkl"),
}

# If only one shared features_used.json is available, reuse for both
if not os.path.exists(paths["xgb_feats"]) and os.path.exists(os.path.join(MODELS_DIR, "features_used.json")):
    paths["xgb_feats"] = os.path.join(MODELS_DIR, "features_used.json")
if not os.path.exists(paths["dtree_feats"]) and os.path.exists(os.path.join(MODELS_DIR, "features_used.json")):
    paths["dtree_feats"] = os.path.join(MODELS_DIR, "features_used.json")

runtime = HydroDemoRuntime(paths)

@app.route("/", methods=["GET"])
def index():
    info = {
        "enriched_range": [str(runtime.df_enriched.index.min()), str(runtime.df_enriched.index.max())],
        "models_loaded": {
            "xgb": runtime.xgb is not None,
            "dtree": runtime.dtree is not None,
            "cnn_lstm": runtime.cnn is not None
        }
    }
    return render_template("index.html", info=json.dumps(info))

@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json(force=True)
    t_str = data.get("datetime")
    result = runtime.predict_all(t_str)
    return jsonify(result)

# ---------- EDA ----------
@app.route("/eda", methods=["GET"])
def eda_home():
    # Attempt to generate plots/summaries on demand
    hydro_path = os.path.join(DATA_DIR, "data_thuydien.csv")
    weather_path = os.path.join(DATA_DIR, "HoaBinh.csv")
    hydro_res = None; weather_res = None
    if os.path.exists(hydro_path):
        hydro_res = run_eda_hydro(hydro_path, os.path.join(PLOTS_DIR, "hydro"))
    if os.path.exists(weather_path):
        weather_res = run_eda_weather(weather_path, os.path.join(PLOTS_DIR, "weather"))
    return render_template("eda.html",
                           hydro=hydro_res, weather=weather_res)

@app.route("/reports/plots/<path:fname>")
def serve_plots(fname):
    return send_from_directory(PLOTS_DIR, fname)

# ---------- Preprocess & Feature Engineering ----------
@app.route("/preprocess", methods=["GET"])
def preprocess_page():
    return render_template("preprocess.html")

@app.route("/preprocess/run", methods=["POST"])
def preprocess_run():
    # expects raw files in data/
    hydro_csv = os.path.join(DATA_DIR, "data_thuydien.csv")
    weather_csv = os.path.join(DATA_DIR, "HoaBinh.csv")
    out_csv = os.path.join(DATA_DIR, "merged_hoa_binh_keyjoin.csv")
    if not os.path.exists(hydro_csv) or not os.path.exists(weather_csv):
        return jsonify({"ok": False, "error": "Thiếu data_thuydien.csv hoặc HoaBinh.csv trong thư mục data/"})
    res = preprocess_merge(hydro_csv, weather_csv, out_csv)
    return jsonify({"ok": True, "result": res})

@app.route("/features", methods=["GET"])
def features_page():
    # if merged exists, allow generating feature list (for tree models)
    merged_csv = os.path.join(DATA_DIR, "merged_hoa_binh_keyjoin.csv")
    feats_json = os.path.join(MODELS_DIR, "features_used.json")
    info = {"can_generate": os.path.exists(merged_csv), "feats_json": os.path.exists(feats_json)}
    return render_template("features.html", info=json.dumps(info))

@app.route("/features/generate", methods=["POST"])
def features_generate():
    merged_csv = os.path.join(DATA_DIR, "merged_hoa_binh_keyjoin.csv")
    feats_json = os.path.join(MODELS_DIR, "features_used.json")
    if not os.path.exists(merged_csv):
        return jsonify({"ok": False, "error": "Chưa có merged_hoa_binh_keyjoin.csv. Hãy chạy Preprocess trước."})
    res = feature_engineer_for_trees(merged_csv, feats_json)
    return jsonify({"ok": True, "result": res, "path": feats_json})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
