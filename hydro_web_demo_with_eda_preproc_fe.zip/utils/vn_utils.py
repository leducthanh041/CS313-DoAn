
import re
import unicodedata

def strip_accents(s: str) -> str:
    if not isinstance(s, str): s = str(s)
    s = unicodedata.normalize("NFKD", s)
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    return s

def normalize_col_vi(c: str) -> str:
    c = strip_accents(str(c)).lower().strip()
    c = re.sub(r"\s+\([^)]*\)", "", c)  # drop units in ()
    c = c.replace("%", "pct").replace("°", "")
    c = re.sub(r"[^a-z0-9_ ]+", "_", c)
    c = re.sub(r"\s+", "_", c)
    c = re.sub(r"_+", "_", c).strip("_")
    return c

def best_match_column(df_cols, wanted: str):
    want = normalize_col_vi(wanted)
    # 1) exact normalized match
    norm_map = {normalize_col_vi(c): c for c in df_cols}
    if want in norm_map: return norm_map[want]
    # 2) contains
    for c in df_cols:
        if want in normalize_col_vi(c):
            return c
    # 3) heuristic alias
    aliases = {
        "thoi_diem": ["time","datetime","timestamp","ngay_gio"],
        "luu_luong_den_ho_m3_s": ["luu_luong_den_ho","luu_luong_den_ho_m3s"],
        "muc_nuoc_thuong_luu_m": ["muc_nuoc_thuong_luu","muc_nuoc_tl"],
        "tong_luong_xa_m3_s": ["tong_luong_xa","tong_xa"],
        "tong_luong_xa_qua_dap_tran_m3_s": ["tong_luong_xa_qua_dap_tran","xa_dap_tran"],
        "tong_luong_xa_qua_nha_may_m3_s": ["tong_luong_xa_qua_nha_may","xa_nha_may"],
        "temperature_2m": ["temperature_2m_c","temp_2m","temp_c","nhiet_do"],
        "relative_humidity_2m": ["relative_humidity_2m_pct","rh_pct","do_am"],
        "precipitation": ["precipitation_mm","mua","mua_mm"],
        "cloud_cover": ["cloud_cover_pct","may_pct"]
    }
    for key, al in aliases.items():
        if want == key or want in al:
            for c in df_cols:
                if normalize_col_vi(c) in [key] + al:
                    return c
    return None
