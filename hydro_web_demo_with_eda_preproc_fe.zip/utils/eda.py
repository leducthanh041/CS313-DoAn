
import os
import json
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from .vn_utils import normalize_col_vi, best_match_column

# Required columns
HYDRO_TARGET_COLS = [
    "thoi_diem",
    "muc_nuoc_thuong_luu_m",
    "luu_luong_den_ho_m3_s",
    "tong_luong_xa_m3_s",
    "tong_luong_xa_qua_dap_tran_m3_s",
    "tong_luong_xa_qua_nha_may_m3_s"
]

WEATHER_TARGET_COLS = [
    "temperature_2m (°C)",
    "relative_humidity_2m (%)",
    "precipitation (mm)",
    "cloud_cover (%)"
]

def smart_read_csv(path):
    for enc in ["utf-8", "utf-8-sig", "cp1258", "latin-1", "utf-16"]:
        try:
            return pd.read_csv(path, encoding=enc)
        except Exception:
            pass
    return pd.read_csv(path)

def select_target_columns(df: pd.DataFrame, wanted: list):
    found = {}
    for w in wanted:
        c = best_match_column(df.columns, w)
        if c is not None: found[w] = c
    # Build new df with canonical order that exists
    cols = [found[w] for w in wanted if w in found]
    out = df[cols].copy()
    # Rename to canonical names for consistency on EDA page
    out.columns = [normalize_col_vi(w) for w in wanted if w in found]
    return out, found

def parse_time_best(series: pd.Series):
    t1 = pd.to_datetime(series, errors="coerce", dayfirst=True)
    t2 = pd.to_datetime(series, errors="coerce", dayfirst=False)
    return t1 if t1.notna().sum() >= t2.notna().sum() else t2

def eda_summary(df: pd.DataFrame, time_col: str = None):
    res = {
        "shape": [int(df.shape[0]), int(df.shape[1])],
        "columns": df.columns.tolist(),
        "dtypes": {c: str(t) for c, t in df.dtypes.items()},
        "missing": {c: int(df[c].isna().sum()) for c in df.columns},
        "head": df.head(5).to_dict(orient="records"),
        "tail": df.tail(5).to_dict(orient="records")
    }
    if time_col and time_col in df.columns:
        dt = parse_time_best(df[time_col])
        if dt.notna().any():
            res["time_range"] = [str(pd.to_datetime(dt.min())), str(pd.to_datetime(dt.max()))]
    return res

def save_plot(fig, out_path: Path):
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)

def run_eda_hydro(csv_path: str, out_dir: str):
    raw = smart_read_csv(csv_path)
    df, colmap = select_target_columns(raw, HYDRO_TARGET_COLS)
    # detect & parse time
    tcol = "thoi_diem" if "thoi_diem" in df.columns else None
    if tcol:
        dt = parse_time_best(df[tcol])
        df[tcol] = dt
        df = df.dropna(subset=[tcol]).sort_values(tcol)

    summary = eda_summary(df, time_col=tcol)

    out_dir = Path(out_dir)
    # 1) Histograms for numeric
    num_cols = [c for c in df.columns if c != tcol and pd.api.types.is_numeric_dtype(df[c])]
    for c in num_cols:
        fig = plt.figure(figsize=(5,3.2))
        ax = fig.add_subplot(111)
        ax.hist(df[c].dropna().values, bins=50)
        ax.set_title(f"Histogram — {c}")
        ax.set_xlabel(c); ax.set_ylabel("Count")
        save_plot(fig, out_dir / f"hydro_hist_{c}.png")

    # 2) Time series for key variables (level, inflow) if time exists
    if tcol and tcol in df.columns:
        for c in [col for col in ["muc_nuoc_thuong_luu_m","luu_luong_den_ho_m3_s"] if col in df.columns]:
            fig = plt.figure(figsize=(9,3.5))
            ax = fig.add_subplot(111)
            ax.plot(df[tcol].values, df[c].values)
            ax.set_title(f"Time series — {c}")
            ax.set_xlabel("thoi_diem"); ax.set_ylabel(c)
            save_plot(fig, out_dir / f"hydro_ts_{c}.png")

    # 3) Correlation (numeric only)
    if len(num_cols) >= 2:
        fig = plt.figure(figsize=(5,4))
        ax = fig.add_subplot(111)
        corr = df[num_cols].corr().values
        cax = ax.imshow(corr, interpolation="nearest")
        ax.set_xticks(range(len(num_cols))); ax.set_xticklabels(num_cols, rotation=45, ha="right")
        ax.set_yticks(range(len(num_cols))); ax.set_yticklabels(num_cols)
        ax.set_title("Correlation (numeric)")
        fig.colorbar(cax, ax=ax, fraction=0.046, pad=0.04)
        save_plot(fig, out_dir / "hydro_corr.png")

    return {"summary": summary, "plots": sorted([p.name for p in out_dir.glob("hydro_*.png")])}

def run_eda_weather(csv_path: str, out_dir: str):
    raw = smart_read_csv(csv_path)
    df, colmap = select_target_columns(raw, WEATHER_TARGET_COLS)

    # no explicit time in weather EDA target; if present, keep it for time series
    time_candidates = [c for c in raw.columns if normalize_col_vi(c) in ["thoi_diem","time","datetime","timestamp"]]
    tcol = None
    if time_candidates:
        tcol = normalize_col_vi(time_candidates[0])
        raw2 = raw.rename(columns={time_candidates[0]: tcol})
        df = pd.concat([raw2[[tcol]], df], axis=1, join="inner") if tcol in raw2.columns else df
        if tcol in df.columns:
            dt = parse_time_best(df[tcol])
            df[tcol] = dt
            df = df.dropna(subset=[tcol]).sort_values(tcol)

    summary = eda_summary(df, time_col=tcol if tcol in df.columns else None)

    out_dir = Path(out_dir)
    num_cols = [c for c in df.columns if c != tcol and pd.api.types.is_numeric_dtype(df[c])]
    for c in num_cols:
        fig = plt.figure(figsize=(5,3.2))
        ax = fig.add_subplot(111)
        ax.hist(df[c].dropna().values, bins=50)
        ax.set_title(f"Histogram — {c}")
        ax.set_xlabel(c); ax.set_ylabel("Count")
        save_plot(fig, out_dir / f"weather_hist_{c}.png")

    if tcol and tcol in df.columns:
        for c in [x for x in num_cols if x != tcol]:
            fig = plt.figure(figsize=(9,3.5))
            ax = fig.add_subplot(111)
            ax.plot(df[tcol].values, df[c].values)
            ax.set_title(f"Time series — {c}")
            ax.set_xlabel("thoi_diem"); ax.set_ylabel(c)
            save_plot(fig, out_dir / f"weather_ts_{c}.png")

    if len(num_cols) >= 2:
        fig = plt.figure(figsize=(5,4))
        ax = fig.add_subplot(111)
        corr = df[num_cols].corr().values
        cax = ax.imshow(corr, interpolation="nearest")
        ax.set_xticks(range(len(num_cols))); ax.set_xticklabels(num_cols, rotation=45, ha="right")
        ax.set_yticks(range(len(num_cols))); ax.set_yticklabels(num_cols)
        ax.set_title("Correlation (numeric)")
        fig.colorbar(cax, ax=ax, fraction=0.046, pad=0.04)
        save_plot(fig, out_dir / "weather_corr.png")

    return {"summary": summary, "plots": sorted([p.name for p in out_dir.glob("weather_*.png")])}
