
from pathlib import Path
import pandas as pd
import numpy as np
import json

from .vn_utils import normalize_col_vi, best_match_column
from .eda import smart_read_csv

# Preprocess: merge hydro + weather (key join by hour) and save merged CSV
def preprocess_merge(hydro_csv: str, weather_csv: str, out_csv: str):
    hydro_raw = smart_read_csv(hydro_csv)
    weather_raw = smart_read_csv(weather_csv)

    # normalize names for robust matching
    hcols = {c: normalize_col_vi(c) for c in hydro_raw.columns}
    wcols = {c: normalize_col_vi(c) for c in weather_raw.columns}

    hydro = hydro_raw.rename(columns=hcols).copy()
    weather = weather_raw.rename(columns=wcols).copy()

    # parse time
    def parse_best(series):
        t1 = pd.to_datetime(series, errors="coerce", dayfirst=True)
        t2 = pd.to_datetime(series, errors="coerce", dayfirst=False)
        return t1 if t1.notna().sum() >= t2.notna().sum() else t2

    time_h = best_match_column(hydro.columns, "thoi_diem") or "thoi_diem"
    time_w = best_match_column(weather.columns, "time") or best_match_column(weather.columns, "thoi_diem") or "time"
    hydro[time_h] = parse_best(hydro[time_h]).dt.floor("H")
    weather[time_w] = parse_best(weather[time_w]).dt.floor("H")

    # Keep required columns
    keep_h = [best_match_column(hydro.columns, x) for x in [
        "muc_nuoc_thuong_luu_m", "luu_luong_den_ho_m3_s",
        "tong_luong_xa_m3_s", "tong_luong_xa_qua_dap_tran_m3_s", "tong_luong_xa_qua_nha_may_m3_s"
    ] if best_match_column(hydro.columns, x) is not None]
    hydro = hydro[[time_h] + keep_h].dropna(subset=[time_h]).drop_duplicates(subset=[time_h]).rename(columns={time_h:"thoi_diem"})

    keep_w = {
        "temperature_2m (°C)": best_match_column(weather.columns, "temperature_2m"),
        "relative_humidity_2m (%)": best_match_column(weather.columns, "relative_humidity_2m"),
        "precipitation (mm)": best_match_column(weather.columns, "precipitation"),
        "cloud_cover (%)": best_match_column(weather.columns, "cloud_cover")
    }
    # filter None
    wsel = ["thoi_diem"]
    weather = weather.rename(columns={time_w:"thoi_diem"})
    for k,v in keep_w.items():
        if v: weather = weather.rename(columns={v: k}); wsel.append(k)
    weather = weather[wsel].dropna(subset=["thoi_diem"]).drop_duplicates(subset=["thoi_diem"])

    merged = pd.merge(hydro, weather, on="thoi_diem", how="inner").sort_values("thoi_diem").reset_index(drop=True)
    Path(out_csv).parent.mkdir(parents=True, exist_ok=True)
    merged.to_csv(out_csv, index=False)
    return {"rows": int(len(merged)), "out": str(out_csv)}

# Feature engineering strictly-past 28d for tree models (same as training logic)
def feature_engineer_for_trees(merged_csv: str, out_features_json: str):
    df = pd.read_csv(merged_csv)
    df["thoi_diem"] = pd.to_datetime(df["thoi_diem"], errors="coerce")
    df = df.dropna(subset=["thoi_diem"]).sort_values("thoi_diem").set_index("thoi_diem")

    # canonical names
    var_map = {
        "muc_nuoc_thuong_luu_m": None,
        "luu_luong_den_ho_m3_s_capped": None,
        "luu_luong_den_ho_m3_s": None,
        "temp_c": None, "rh_pct": None, "precip_mm": None, "cloud_pct": None
    }
    # try to find columns
    for c in df.columns:
        lc = normalize_col_vi(c)
        if lc in var_map:
            var_map[lc] = c
        # map from display with units
        if lc == "temperature_2m": var_map["temp_c"] = c
        if lc == "relative_humidity_2m": var_map["rh_pct"] = c
        if lc == "precipitation": var_map["precip_mm"] = c
        if lc == "cloud_cover": var_map["cloud_pct"] = c

    target = var_map["muc_nuoc_thuong_luu_m"]
    inflow = var_map["luu_luong_den_ho_m3_s_capped"] or var_map["luu_luong_den_ho_m3_s"]
    weather_cols = [x for x in [var_map["temp_c"], var_map["rh_pct"], var_map["precip_mm"], var_map["cloud_pct"]] if x]

    VAR_LIST = [v for v in [target, inflow] + weather_cols if v]
    if not target or not inflow:
        raise ValueError("Thiếu cột target hoặc inflow trong merged.")

    feat = pd.DataFrame(index=df.index)
    feat["hour"] = feat.index.hour
    feat["dow"] = feat.index.dayofweek
    feat["month"] = feat.index.month
    feat["is_weekend"] = (feat["dow"] >= 5).astype(int)

    def roll_feats(s, name):
        s = s.shift(1)
        for w in ["24H","3D","7D","14D","28D"]:
            r = s.rolling(w, closed="left")
            feat[f"{name}__mean_{w.lower()}"] = r.mean()
            feat[f"{name}__std_{w.lower()}"] = r.std()
            feat[f"{name}__max_{w.lower()}"] = r.max()
            feat[f"{name}__min_{w.lower()}"] = r.min()

    def lag_feats(s, name):
        for k in [1,3,6,12,24,48,72]:
            feat[f"{name}__lag_{k}"] = s.shift(k)

    for col in VAR_LIST:
        roll_feats(df[col], col)
        lag_feats(df[col], col)

    feature_list = feat.columns.tolist()
    Path(out_features_json).parent.mkdir(parents=True, exist_ok=True)
    with open(out_features_json, "w", encoding="utf-8") as f:
        json.dump(feature_list, f, ensure_ascii=False, indent=2)

    return {"n_features": len(feature_list), "out": str(out_features_json)}
